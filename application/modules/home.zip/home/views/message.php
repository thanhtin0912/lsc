<table style="width:538px;background-color:#393836" align="center" cellspacing="0" cellpadding="0">
	<tbody>
		<tr>
			<td style="height:65px;background-color:#171a21;border-bottom:1px solid #4d4b48">
				<img src="https://haiduongengineer.com/assets/images/resources/logo.png" width="538" height="65" alt="Steam" class="CToWUd">
			</td>
		</tr>
		<tr>
			<td bgcolor="#17212e">
				<table width="470" border="0" align="center" cellpadding="0" cellspacing="0" style="padding-left:5px;padding-right:5px;padding-bottom:10px">
					<tbody>
						<tr bgcolor="#17212e">
							<td style="padding-top:32px">
							<span style="padding-top:16px;padding-bottom:16px;font-size:24px;color:#66c0f4;font-family:Arial,Helvetica,sans-serif;font-weight:bold">
								Khách hàng <?php echo $name ?>,
							</span><br>
							</td>
						</tr>
						
						<tr>
							<td style="padding-top:12px">
								<span style="font-size:17px;color:#c6d4df;font-family:Arial,Helvetica,sans-serif;font-weight:bold">
									<p>Số điện thoại: <?php echo $name ?></p>
									<p>Email: <?php echo $mail ?></p>
								</span>
							</td>
						</tr>

						<tr bgcolor="#121a25">
							<td style="padding:20px;font-size:12px;line-height:17px;color:#c6d4df;font-family:Arial,Helvetica,sans-serif">
									<p style="padding-bottom:10px;color:#c6d4df"></p>
							</td>

						</tr>


						<tr>
							<td style="font-size:12px;color:#6d7880;padding-top:16px;padding-bottom:60px">
		                    	<span style="color:#ffffff;font-weight:bold"><?php echo $message ?></span>
		                    </td>
						</tr>

					</tbody>
				</table>
			</td>
		</tr>

		<tr style="background-color:#000000">
			<td style="padding:12px 24px">
				<table cellpadding="0" cellspacing="0">
					<tbody><tr>
						<td width="92">
							<img src="https://haiduongengineer.com/assets/images/resources/logo.png" width="92" height="26" alt="Valve®" class="CToWUd">
						</td>
						<td style="font-size:11px;color:#595959;padding-left:12px">
						<div style="margin:0px;font-stretch:normal;line-height:normal;font-family:Calibri"><b>CÔNG TY TNHH TM DV KỸ THUẬT HẢI DƯƠNG</b></div>
						<div style="margin:0px;font-stretch:normal;line-height:normal;font-family:Calibri"><b>187/12 Nguyễn An, Vĩnh Hòa, Tp. Nha Trang, Khánh Hòa</b></div>
						<div style="margin:0px;font-stretch:normal;line-height:normal;font-family:Calibri"><b>Phone:(84).905.721.359</b></div>
						<div style="margin:0px;font-stretch:normal;line-height:normal;font-family:Calibri"><b>Email: diennd.hds@gmail.com</b></div>
					</td>
					</tr>
				</tbody></table>
			</td>
		</tr>
	</tbody>
</table>


