

<table style="width:538px;background-color:#393836" align="center" cellspacing="0" cellpadding="0">
	<tbody>
		<tr>
			<td bgcolor="#17212e">
				<table width="470" border="0" align="center" cellpadding="0" cellspacing="0" style="padding-left:5px;padding-right:5px;padding-bottom:10px">

					<tbody>
						<tr bgcolor="#17212e">
							<td style="padding-top:32px">
							<span style="font-size:24px;color:#66c0f4;font-family:Arial,Helvetica,sans-serif;font-weight:bold">
								Dear <a href="mailto:<?php echo $mail?>">,<?php echo $firstname ?></a></span>
							</td>
						</tr>

						<tr>
							<td style="padding-top:12px;font-size:17px;color:#c6d4df;font-family:Arial,Helvetica,sans-serif;font-weight:bold">
								<p>Thank you for registering at our K2 office website. You now have full access to our website to see our price and special offers.</p>
								<p>This is your account details:</p></td>
						</tr>
                    	<tr bgcolor="#121a25">
							<td style="padding:20px;font-size:12px;line-height:17px;color:#c6d4df;font-family:Arial,Helvetica,sans-serif">
							    <p>Username : <span style="font-size:18px;color:#66c0f4;font-family:Arial,Helvetica,sans-serif;font-weight:bold"><?php echo $mail ?></span> </p>
							    <p>Password : <span style="font-size:18px;color:#66c0f4;font-family:Arial,Helvetica,sans-serif;font-weight:bold"><?php echo $pass ?></span> </p>
							</td>
						</tr>

                        <tr>
							<td style="padding-top:12px;font-size:17px;color:#c6d4df;font-family:Arial,Helvetica,sans-serif;font-weight:bold">
								<p>When sign into your account, please change your password immediately by visiting your account settings on K2OFFICE.</p>
						</tr>
                        <tr>
        					<td style="font-size:12px;color:#6d7880;padding-top:16px;padding-bottom:60px">
                    			Yours <span class="il">Sincerely</span>,<br>
                    			<a style="color:#8f98a0" href="www.k2office.com.au" target="_blank">www.k2office.com.au</a><br>
                            </td>
        				</tr>
					</tbody>
				</table>
			</td>
		</tr>

		<tr style="background-color:#000000">
			<td style="padding:12px 24px">
				<table cellpadding="0" cellspacing="0">
					<tbody><tr>
					    <td width="92">
							<img src="http://k2components.com.au/img/logo.jpg"  height="100%"  class="CToWUd">
						</td>
						<td style="font-size:13px;color:#595959;padding-left:12px">
						<div style="margin:0px;font-stretch:normal;line-height:normal;font-family:Calibri"><b>K2OFFICE Pty. Ltd.,</b></div>
						<div style="margin:0px;font-stretch:normal;line-height:normal;font-family:Calibri"><b>17-19 Myuna Street, Regency Park, South Australia 5010.</b></div>
						<div style="margin:0px;font-stretch:normal;line-height:normal;font-family:Calibri"><b>Ph: +61 8 8268 1122</b></div>
						<div style="margin:0px;font-stretch:normal;line-height:normal;font-family:Calibri"><b>Fx: +61 8 8268 4663</b></div>
					</td>
					</tr>
				</tbody></table>
			</td>
		</tr>
	</tbody>
</table>




